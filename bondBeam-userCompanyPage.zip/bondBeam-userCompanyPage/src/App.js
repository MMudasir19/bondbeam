import { Box } from "@mui/material";
import * as React from "react";
import { useAPI } from "./components/Hooks/useContext";
import MainComponent from "./components/MainComponent/MainComponent";
import MenuBar from "./components/MenuBar/MenuBar";
import UserDp from "./components/UserDp/UserDp";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Loading from "./components/Hooks/useLoading";
import GroupDp from "./userGroupComponents/groupDp/GroupDp";
import UserGroupComponent from "./userGroupComponents/UserGroupComponent";

function App() {
  const { isLoading } = useAPI();
  return (
    <>
      <BrowserRouter>
        {!isLoading ? (
          <>
            <Box backgroundColor="#E5E5E5">
              <Routes>
                <Route
                  index
                  path="/companyProfile"
                  exact
                  element={
                    <>
                      <UserDp />
                      <MenuBar />
                      <MainComponent />
                    </>
                  }
                />
                <Route
                  path="/"
                  exact
                  element={
                    <>
                      <GroupDp />
                      <UserGroupComponent />
                    </>
                  }
                />
              </Routes>
            </Box>
          </>
        ) : (
          <Box
            position="fixed"
            width="100%"
            height="100%"
            zIndex={9999}
            left="50%"
            top="50%"
          >
            <Loading />
          </Box>
        )}
      </BrowserRouter>
    </>
  );
}

export default App;
