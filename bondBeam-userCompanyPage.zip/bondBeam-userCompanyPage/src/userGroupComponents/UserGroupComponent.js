import { Grid } from "@mui/material";
import * as React from "react";
import GroupAbout from "./groupAbout/GroupAbout";
import GroupDetail from "./groupDetail/GroupDetail";
import GroupInfo from "./groupInfo/GroupInfo";
import GroupMedia from "./groupMedia/GroupMedia";

export default function UserGroupComponent() {
  return (
    <>
      <Grid
        container
        p={{ xs: "6rem 1rem", md: "4rem 0rem 0rem 0rem" }}
        direction={{ md: "row" }}
        width="100%"
        mt={{ xs: 7, md: 0 }}
      >
        <Grid
          maxHeight={1250}
          overflow="auto"
          sx={{
            "::-webkit-scrollbar": {
              display: "none",
            },
            msOverflowStyle: "none",
            scrollbarWidth: "none",
          }}
          item
          container
          xs={12}
          md={3}
          p={{ xs: "0rem 0.5rem", md: "0rem 1rem" }}
        >
          <Grid item xs={12} m="0.7rem 0rem">
            <GroupAbout />
          </Grid>
          <Grid item xs={12} m="0.7rem 0rem">
            <GroupInfo />
          </Grid>
          <Grid item xs={12} m="0.7rem 0rem">
            <GroupMedia />
          </Grid>
        </Grid>

        <Grid item container xs={12} md={9}>
          <Grid item container xs={12} ml={{ md: "1rem" }}>
            <Grid
              item
              container
              xs={12}
              md={8}
              m={{ xs: "0.4rem", md: "0.1rem 0rem" }}
              borderRadius={2}
              maxHeight={2300}
              overflow="auto"
              sx={{
                "::-webkit-scrollbar": {
                  display: "none",
                },
              }}
            >
              {/* GroupTimeLine */}
              <GroupDetail />
              <GroupDetail />
            </Grid>
            <Grid
              item
              container
              xs={12}
              md={4}
              order={{ xs: -1, md: 0 }}
              maxHeight={2000}
              overflow="auto"
            >
              <GroupDetail />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
}
