import { Avatar, Button, Grid, Stack, Typography } from "@mui/material";
import { useState } from "react";
import { Link } from "react-router-dom";
import RoundedPic from "../../../images/userDp.jpg";
import VerifiedIcon from "@mui/icons-material/Verified";

const JoinRequest = ({ followers }) => {
  const [allFollowers, setAllFollowers] = useState(8);
  const [showFollowesMore, setShowFollowesMore] = useState(false);
  const userData = JSON.parse(localStorage.getItem("userLoggedIn"));
  // console.log();
  const LoguserId = userData?.data?.id;
  return (
    <>
      <Grid
        // spacing={3}
        item
        container
        maxHeight="253px"
        overflow="auto"
        // justifyContent="space-around"
        alignItems="center"
        xs={12}
        p={2}
        borderRadius="10px"
        border="2px solid silver"
        backgroundColor="white"
      >
        <Grid item xs={12}>
          <Typography fontSize="x-large" fontWeight={800}>
            Join Requests ({followers?.length ? followers?.length : 0})
          </Typography>
        </Grid>
        {followers?.slice(0, 4).map((props) => (
          <Grid
            item
            p={1}
            key={props.follower_user.id}
            xs={12}
            sm={6}
            md={4}
            lg={3}
            mt={2}
          >
            <Stack direction="column" rowGap={1} alignItems="center">
              <Link
                style={{
                  textDecoration: "none",
                  color: "black",
                  textTransform: "capitalize",
                }}
                to={
                  props.follower_user.id === LoguserId
                    ? "/myprofile"
                    : `/userprofile/${props.follower_user.id}`
                }
              >
                <Avatar
                  width="50px"
                  height="50px"
                  src={
                    props.follower_user.user_pic
                      ? props.follower_user.user_pic
                      : RoundedPic
                  }
                  alt={props.follower_user.username}
                />
              </Link>
              <Link
                style={{
                  textDecoration: "none",
                  color: "black",
                  textTransform: "capitalize",
                  fontSize: "12px",
                }}
                to={
                  props.follower_user.id === LoguserId
                    ? "/myprofile"
                    : `/userprofile/${props.follower_user.id}`
                }
              >
                <Stack
                  direction="row"
                  alignItems="center"
                  justifyContent="center"
                  columnGap={1}
                >
                  <p
                    style={{ fontWeight: "bold", textTransform: "capitalize" }}
                  >
                    {props.follower_user.first_name}
                    {/* &nbsp;{props.follower_user.last_name} */}
                  </p>
                  {props.follower_user.is_verified === "Approved" && (
                    <VerifiedIcon color="info" />
                  )}
                </Stack>
              </Link>
            </Stack>
          </Grid>
        ))}

        <Grid item xs={12}>
          {followers?.length > 4 && (
            <Link
              style={{ textDecoration: "none" }}
              to={`/allfollowers/${LoguserId}`}
            >
              <Button
                sx={{
                  width: "100%",
                }}
                variant="contained"
              >
                See all
              </Button>
            </Link>
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default JoinRequest;
