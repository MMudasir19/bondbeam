import { Box, Grid, Stack, Typography } from "@mui/material";
import { groupData } from "../SimilarGroups/SimilarGroupData";
import { useNavigate } from "react-router-dom";

const Likes = () => {
  let navigate = useNavigate();
  const ComingSoon = () => {
    navigate("/commingsoon");
  };
  return (
    <>
      <Grid
        item
        rowGap={2}
        container
        xs={12}
        p={2}
        backgroundColor="white"
        borderRadius="10px"
        border="2px solid silver"
      >
        <Grid item xs={12}>
          <Typography fontSize="x-large" fontWeight={800}>
            Likes
          </Typography>
        </Grid>
        {groupData.map(({ id, img, name, followers }) => (
          <Grid item xs={6} md={12} key={id}>
            <Stack
              onClick={ComingSoon}
              sx={{ cursor: "pointer" }}
              direction="row"
              columnGap={1}
              alignItems="center"
            >
              <Box
                component="img"
                src={img}
                alt="follower1"
                width="15%"
                borderRadius="50%"
              />
              <p style={{ fontWeight: "bold" }}>
                {name}
                <br />
                <span style={{ color: "#0A66C2", fontWeight: "normal" }}>
                  {followers} Followers
                </span>
              </p>
            </Stack>
          </Grid>
        ))}
      </Grid>
    </>
  );
};

export default Likes;
