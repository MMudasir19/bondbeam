import { Grid } from "@mui/material";
import React from "react";
import GroupMember from "./GroupMember/GroupMember";
import JoinRequest from "./JoinRequest/JoinRequest";
import Likes from "./Likes/Likes";
import Products from "./Products/Products";
import SimilarGroups from "./SimilarGroups/SimilarGroups";

export default function GroupDetail() {
  return (
    <>
      <Grid item container xs={12} p={1}>
        <GroupMember />
      </Grid>
      <Grid item container xs={12} p={1}>
        <JoinRequest />
      </Grid>
      <Grid item container xs={12} p={1}>
        <SimilarGroups />
      </Grid>
      <Grid item container xs={12} p={1}>
        <Likes />
      </Grid>
      <Grid item container xs={12} p={1}>
        <Products />
      </Grid>
    </>
  );
}
