import Group1 from "../../../images/userDp.jpg";

export const groupData = [
  {
    id: 1,
    name: "Php Developers",
    followers: "102k",
    img: Group1,
  },
  {
    id: 2,
    name: "Front End",
    followers: "102k",
    img: Group1,
  },
  {
    id: 3,
    name: "Code Learning",
    followers: "102k",
    img: Group1,
  },
  {
    id: 4,
    name: "Project Creator",
    followers: "102k",
    img: Group1,
  },
];
