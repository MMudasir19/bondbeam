import {
  Grid,
  IconButton,
  ImageList,
  ImageListItem,
  ImageListItemBar,
  Typography,
} from "@mui/material";
import { productsData } from "./ProductData";
import { useNavigate } from "react-router";

const Products = () => {
  let navigate = useNavigate();
  // const HandleImg = () => {
  //   navigate("/commingsoon");
  // };
  return (
    <>
      <Grid
        item
        rowGap={2}
        container
        xs={12}
        p={2}
        className="rightArea"
        backgroundColor="white"
        sx={{ borderRadius: "10px", border: "2px solid silver" }}
      >
        <Grid item xs={12}>
          <Typography fontSize="x-large" fontWeight={800}>
            Products
          </Typography>
        </Grid>

        <ImageList
          className="rightArea"
          sx={{
            cursor:"pointer",
            width: "100%",
            height: 450,
            "::-webkit-scrollbar": {
              display: "none",
            },
            msOverflowStyle: "none",
            scrollbarWidth: "none",
          }}
        >
          <ImageListItem key="Subheader" cols={2} gap={8}>
            {/* <ListSubheader component="div">December</ListSubheader> */}
          </ImageListItem>
          {productsData.map((item) => (
            <ImageListItem key={item.img}>
              <img
                onClick={() => navigate("/commingsoon")}
                src={`${item.img}?w=248&fit=crop&auto=format`}
                srcSet={`${item.img}?w=248&fit=crop&auto=format&dpr=2 2x`}
                alt={item.title}
                loading="lazy"
              />
              <ImageListItemBar
                title={item.title}
                subtitle={item.price}
                actionIcon={
                  <IconButton
                    sx={{ color: "rgba(255, 255, 255, 0.54)" }}
                    aria-label={`info about ${item.title}`}
                  ></IconButton>
                }
              />
            </ImageListItem>
          ))}
        </ImageList>

        {/* 
          {productsData.map(({ id, img, price }) => (
            <Grid item xs={6} key={id}>
              <Box
                onClick={HandleImg}
                sx={{
                  backgroundImage: `url(${img})`,
                  backgroundSize: "cover",
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "center center",
                  width: "100%",
                  height: "200px",
                  cursor: "pointer",
                  display: "flex",
                  justifyContent: "flex-end",
                  alignItems: "flex-end",
                }}
              >
                <Button
                  variant="text"
                  sx={{
                    background: "rgba(0, 0, 0, 0.4)",
                    borderRadius: "5px",
                    border: "1px solid white",
                    color: "white",
                    margin: "20px",
                  }}
                >
                  ${price}
                </Button>
              </Box>
            </Grid>
          ))} */}
      </Grid>
    </>
  );
};

export default Products;
