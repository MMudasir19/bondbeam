import { Grid, Stack, Typography } from "@mui/material";
import React from "react";
import userGroupDp from "../../images/userGroupDp.png";
import userGroupCover from "../../images/userGroupCover.png";
import { makeStyles } from "@mui/styles";
import Box from "@mui/material/Box";
import EditIcon from "@mui/icons-material/Edit";
import MoreVertSharpIcon from "@mui/icons-material/MoreVertSharp";

const userCoverStyles = makeStyles({
  root: {
    backgroundSize: "cover",
    backgroundPosition: "center center",
    backgroundRepeat: "no-repeat",
  },
});
export default function GroupDp() {
  const styles = userCoverStyles();
  return (
    <>
      <Grid container direction="row" height={300}>
        <Grid item container xs={12} md={9} p={2} height={300}>
          <Stack width="100%">
            <Box
              sx={{ backgroundImage: `url(${userGroupCover})` }}
              className={styles.root}
              border="2px solid silver"
              borderRadius={2}
              width="100%"
              height={300}
            >
              <Box
                component="label"
                htmlFor="file-input"
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  padding: 1,
                  cursor: "pointer",
                  color: "white",
                }}
              >
                <EditIcon
                  sx={{
                    padding: 1,
                    borderRadius: "50%",
                    backgroundColor: "rgb(0,0,0,0.7)",
                    "&:hover": {
                      color: "white",
                      backgroundColor: "rgb(0,0,0,.8)",
                    },
                  }}
                />
                <Box
                  component="input"
                  id="file-input"
                  type="file"
                  display="none"
                />
              </Box>
              <Grid
                item
                container
                height={210}
                xs={12}
                direction="row"
                alignItems={"flex-end"}
                p="0rem 0.5rem 0rem 4rem"
                display={{ xs: "none", md: "flex" }}
                justifyContent="space-between"
              >
                <Stack>
                  <Typography variant="h6" color="white" fontSize="2rem">
                    MyGroup
                  </Typography>
                  <Typography variant="p" color="white" fontSize="large">
                    @mygroup
                  </Typography>
                </Stack>
                <Stack>
                  <MoreVertSharpIcon
                    fontSize="large"
                    sx={{
                      transform: {
                        xs: "rotateZ(90deg)",
                        sm: "rotateZ(180deg)",
                      },
                      color: "white",
                      cursor: "pointer",
                    }}
                  />
                </Stack>
              </Grid>
            </Box>
          </Stack>
        </Grid>
        <Grid
          order={{ md: -1 }}
          item
          container
          md={3}
          xs={12}
          height={300}
          mt={{ xs: -7, md: 0 }}
          p={2}
          display="flex"
          justifyContent="center"
        >
          <Stack
            width={{ md: "100%" }}
            height={{ xs: 200, md: 300 }}
            display="flex"
            justifyContent="center"
          >
            <Box
              sx={{ backgroundImage: `url(${userGroupDp})` }}
              className={styles.root}
              border={{ md: "2px solid silver" }}
              borderRadius={2}
              width="100%"
              height={{ xs: 250, md: 300 }}
            >
              <Box
                component="label"
                htmlFor="file-input"
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  padding: 1,
                  cursor: "pointer",
                  color: "white",
                }}
              >
                <EditIcon
                  sx={{
                    padding: 1,
                    borderRadius: "50%",
                    backgroundColor: "rgb(0,0,0,0.7)",
                    "&:hover": {
                      color: "white",
                      backgroundColor: "rgb(0,0,0,.8)",
                    },
                  }}
                />
              </Box>
              <Box
                component="input"
                id="file-input"
                type="file"
                display="none"
              />
            </Box>
            <Grid
              item
              container
              height={180}
              xs={12}
              direction="row"
              display={{ xs: "block", md: "none" }}
              justifyContent="center"
            >
              <Stack>
                <Typography
                  variant="h6"
                  color={{ md: "white" }}
                  fontSize="2rem"
                >
                  MyGroup
                </Typography>
                <Typography
                  variant="p"
                  color={{ xs: "gray", md: "white" }}
                  fontSize="large"
                >
                  @mygroup
                </Typography>
              </Stack>
            </Grid>
          </Stack>
        </Grid>
      </Grid>
    </>
  );
}
