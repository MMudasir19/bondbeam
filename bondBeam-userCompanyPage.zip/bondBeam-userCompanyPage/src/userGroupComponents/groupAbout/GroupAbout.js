import { Stack, Typography } from "@mui/material";
import React from "react";
import EditIcon from "@mui/icons-material/Edit";
import { Scrollbars } from "react-custom-scrollbars-2";

export default function GroupAbout() {
  return (
    <>
      <Stack
        p={2}
        border={"2px solid silver"}
        borderRadius={2}
        backgroundColor="white"
      >
        <Stack direction="row" width="100%" justifyContent="space-between">
          <Typography
            color="black"
            variant="h6"
            fontSize="x-large"
            fontWeight={800}
          >
            About
          </Typography>
          <EditIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
        </Stack>

        <Typography
          textOverflow="ellipsis"
          maxHeight={300}
          overflow="auto"
          sx={{
            "::-webkit-scrollbar": {
              display: "none",
            },
            msOverflowStyle: "none",
            scrollbarWidth: "none",
          }}
        >
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged.
        </Typography>
      </Stack>
    </>
  );
}
