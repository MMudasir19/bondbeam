import { Stack, Typography } from "@mui/material";
import React from "react";
import EditIcon from "@mui/icons-material/Edit";
import LocalPhoneOutlinedIcon from "@mui/icons-material/LocalPhoneOutlined";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import AutoStoriesOutlinedIcon from "@mui/icons-material/AutoStoriesOutlined";
import BusinessCenterOutlinedIcon from "@mui/icons-material/BusinessCenterOutlined";

export default function GroupInfo() {
  return (
    <>
      <Stack
        p={2}
        border={"2px solid silver"}
        borderRadius={2}
        backgroundColor="white"
        overflow="hidden"
        textOverflow="ellipsis"
      >
        <Stack direction="row" width="100%" justifyContent="space-between">
          <Typography
            color="black"
            variant="h6"
            fontSize="x-large"
            fontWeight={800}
          >
            Info
          </Typography>
          <EditIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
        </Stack>
        <Stack maxHeight={300} direction="row">
          <BusinessCenterOutlinedIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
          <Typography color="gray" p={1}>
            Web developer at
            <Typography
              pl={0.5}
              sx={{ cursor: "pointer" }}
              variant="span"
              color="#585858"
              fontWeight={800}
            >
              HiSoft
            </Typography>
          </Typography>
        </Stack>
        <Stack maxHeight={300} direction="row">
          <AutoStoriesOutlinedIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
          <Typography color="gray" p={1}>
            Studied at
            <Typography
              pl={0.5}
              sx={{ cursor: "pointer" }}
              variant="span"
              color="#585858"
              fontWeight={800}
            >
              University of Engineering & Technology
            </Typography>
          </Typography>
        </Stack>
        <Stack maxHeight={300} direction="row">
          <LocationOnOutlinedIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
          <Typography color="gray" p={1}>
            Lives in
            <Typography
              pl={0.5}
              sx={{ cursor: "pointer" }}
              variant="span"
              color="#585858"
              fontWeight={800}
            >
              Lahore
            </Typography>
          </Typography>
        </Stack>
        <Stack maxHeight={300} direction="row">
          <FavoriteBorderOutlinedIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
          <Typography color="gray" p={1}>
            Single
          </Typography>
        </Stack>
        <Stack maxHeight={300} direction="row">
          <LocalPhoneOutlinedIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
          <Typography color="gray" p={1}>
            (092) 456-9875
          </Typography>
        </Stack>
      </Stack>
    </>
  );
}
