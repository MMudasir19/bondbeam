import React, { useContext, useState, useEffect, createContext } from "react";

const APIContext = createContext();

function APIContextProvider({ children }) {
  const [data, setData] = useState([]);
  const [similarData, setSimilarData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    company();
    similarCompanies();
    // eslint-disable-next-line
  }, []);
  const company = () => {
    var myHeaders = new Headers();
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjgwODUyMzcwLCJpYXQiOjE2NzMwNzYzNzAsImp0aSI6IjFlZDEyZGQ0NGRmNTQ1Yjk4YWU2ODI1NmExNzMyMDQ2IiwidXNlcl9pZCI6OTB9.5pezlKIOYGbHzA9Nw2FON2RFs2ODJBW2_NWzeN8fazI"
    );

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch("https://api.bondbeam.com/company/companies/4", requestOptions)
      .then((response) => response.json())
      .then((result) => setData(result.data))
      .catch((error) => console.log("error", error))
      .then(() => setIsLoading(!isLoading));
  };

  const similarCompanies = () => {
    var myHeaders = new Headers();
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjgwODUyMzcwLCJpYXQiOjE2NzMwNzYzNzAsImp0aSI6IjFlZDEyZGQ0NGRmNTQ1Yjk4YWU2ODI1NmExNzMyMDQ2IiwidXNlcl9pZCI6OTB9.5pezlKIOYGbHzA9Nw2FON2RFs2ODJBW2_NWzeN8fazI"
    );

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch("https://api.bondbeam.com/company/companies", requestOptions)
      .then((response) => response.json())
      .then((result) => setSimilarData(result.results))
      .catch((error) => console.log("error", error));
  };

  return (
    <APIContext.Provider value={{ data, isLoading, similarData }}>
      {children}
    </APIContext.Provider>
  );
}

export default APIContextProvider;

export function useAPI() {
  const context = useContext(APIContext);
  if (context === undefined) {
    throw new Error("Context must be used within a Provider");
  }
  return context;
}
