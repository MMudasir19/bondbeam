import { useState } from "react";

export const useShowMore = () => {
  const [showMore, setShowMore] = useState(false);

  return {
    setShowMore,
    showMore,
  };
};
