import PulseLoader from "react-spinners/PulseLoader";

const override = {
  display: "flex",
  margin: "0 auto",
};

function Loading() {
  return <PulseLoader color="gray" size={10} cssOverride={override} />;
}

export default Loading;
