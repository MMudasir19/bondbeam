import { useState } from "react";

export const useReport = () => {
  const [anchorEl, setAnchorEl] = useState(null);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  return {
    handleMenu,
    handleClose,
    anchorEl,
  };
};
