import React from "react";
import { Stack, Typography } from "@mui/material";
import { useAPI } from "../../Hooks/useContext";
import EditIcon from "@mui/icons-material/Edit";

export default function About() {
  const { data } = useAPI();
  const about = data.company;
  return (
    <>
      <Stack
        sx={{
          backgroundColor: "white",
          border: "2px solid silver",
          borderRadius: "10px",
          padding: 2,
        }}
      >
        <Stack direction="row" width="100%" justifyContent="space-between">
          <Typography
            color="inherit"
            variant="h4"
            fontWeight={800}
            p={{
              xs: "1rem 0rem",
              sm: "7px 0px",
              md: "5px 0px",
              lg: "2px 0px",
            }}
            fontSize={{ xs: "1.5rem", sm: "1.2rem", md: "1.8rem", lg: "2rem" }}
          >
            About
          </Typography>
          <EditIcon
            sx={{
              padding: 1,
              borderRadius: "50%",
              cursor: "pointer",
              "&:hover": {
                backgroundColor: "rgb(0,0,0,.2)",
              },
            }}
          />
        </Stack>
        <Typography>{about.company_about}</Typography>
      </Stack>
    </>
  );
}
