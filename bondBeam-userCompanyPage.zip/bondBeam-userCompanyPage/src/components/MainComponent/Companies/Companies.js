import { Box, Stack, Typography } from "@mui/material";
import * as React from "react";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import locationGray from "../../../images/locationgray.png";
import WatchLaterOutlinedIcon from "@mui/icons-material/WatchLaterOutlined";
import { useAPI } from "../../Hooks/useContext";

export default function Companies() {
  const { similarData } = useAPI();
  return (
    <>
      <Grid
        item
        container
        xs={12}
        p={{ xs: 0, sm: 2 }}
        backgroundColor="white"
        borderRadius="10px"
        border="2px solid silver"
      >
        <Typography
          color="inherit"
          variant="h4"
          fontWeight={800}
          mb={2}
          p={{
            xs: "1rem 0rem 0rem 1rem",
            sm: "7px 0px",
            md: "5px 0px",
            lg: "2px 0px",
          }}
          fontSize={{ xs: "1.5rem", sm: "1.2rem", md: "1.8rem", lg: "2rem" }}
        >
          Similar Companies
        </Typography>

        <Grid
          item
          container
          xs={12}
          maxHeight={800}
          overflow="auto"
          sx={{
            "::-webkit-scrollbar": {
              display: "none",
            },
            msOverflowStyle: "none",
            scrollbarWidth: "none",
          }}
        >
          {similarData.map((item) => {
            return (
              <Stack
                sx={{ cursor: "pointer" }}
                key={item.id}
                direction="row"
                p={1}
                m={1}
                width="100%"
                backgroundColor="white"
                borderRadius="10px"
                border="2px solid silver"
              >
                <Box
                  component="img"
                  src={item.profile_pic}
                  width="3rem"
                  height="3rem"
                  borderRadius="50%"
                  border="1px solid black"
                />

                <Stack p={1} pt={{ xs: 0, lg: 1 }} width="100%">
                  <Typography
                    fontSize={{ xs: "medium", lg: "large" }}
                    fontWeight={800}
                    color="inherit"
                  >
                    {item.company_name}
                  </Typography>

                  <Typography
                    variant="body2"
                    maxHeight={{ xs: "5rem", lg: "9rem" }}
                    overflow="hidden"
                  >
                    {item.company_description}
                  </Typography>
                  <Stack
                    p="10px 0px"
                    direction="row"
                    justifyContent="space-between"
                  >
                    <Stack direction="row" sx={{ cursor: "pointer" }}>
                      <Box
                        component="img"
                        src={locationGray}
                        width={{ xs: "0.7rem", lg: "1rem" }}
                        height={{ xs: "0.7rem", lg: "1rem" }}
                      />
                      <Typography
                        p="0px 10px"
                        fontSize={{ xs: "10px", lg: "small" }}
                        color="gray"
                      >
                        {item.company_address}
                      </Typography>
                    </Stack>
                    <Stack direction="row" sx={{ cursor: "pointer" }}>
                      <WatchLaterOutlinedIcon
                        sx={{
                          color: "gray",
                          width: { xs: "1rem", lg: "1.5rem" },
                          height: { xs: "1rem", lg: "1.5rem" },
                        }}
                      />
                      <Typography
                        p="0px 10px"
                        fontSize={{ xs: "10px", lg: "small" }}
                        color="gray"
                      >
                        {item.working_shift}
                      </Typography>
                    </Stack>
                  </Stack>
                  <Stack
                    direction="row"
                    width="100%"
                    justifyContent="space-between"
                  >
                    <Button
                      size="small"
                      variant="fiiled"
                      sx={{
                        backgroundColor: "black",
                        color: "white",
                        "&:hover": {
                          color: "white",
                          backgroundColor: "black",
                        },
                      }}
                    >
                      Follow
                    </Button>
                  </Stack>
                </Stack>
              </Stack>
            );
          })}
        </Grid>
      </Grid>
    </>
  );
}
