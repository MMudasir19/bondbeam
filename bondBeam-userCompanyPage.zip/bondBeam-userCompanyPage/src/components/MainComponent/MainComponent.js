import * as React from "react";
import About from "./About/About";
import { Grid } from "@mui/material";
import Projects from "./Projects/Projects";
import RecentJobsPosted from "./RecentJobsPosted/RecentJobsPosted";
import Chats from "./Chats/Chats";
import Companies from "./Companies/Companies";

export default function MainComponent() {
  return (
    <>
      <Grid container>
        <Grid item container xs={12} md={7} p={{ sm: 1 }}>
          <Grid item xs={12} pt={2}>
            <About />
            {/* only visible in mobile start */}
            <Grid item xs={12} display={{ xs: "block", md: "none" }} pt={3}>
              <Companies />
            </Grid>
            {/* only visible in mobile end */}
          </Grid>
          <Grid item xs={12} display={{ xs: "none", sm: "block" }} pt={3}>
            <Projects />
          </Grid>
          <Grid item container direction="row" spacing={{ md: 1 }} pt={3}>
            <Grid item container xs={12} lg={6}>
              <RecentJobsPosted />
            </Grid>
            <Grid item container xs={12} lg={6} pt={3}>
              <Chats />
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={5} display={{ xs: "none", md: "block" }} p={1} pt={3}>
          <Companies />
        </Grid>
      </Grid>
    </>
  );
}
