import { Stack, Typography } from "@mui/material";
import * as React from "react";
import Box from "@mui/material/Box";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import locationGray from "../../../images/locationgray.png";
import WatchLaterOutlinedIcon from "@mui/icons-material/WatchLaterOutlined";
import jobs from "./JobsData";
import { Scrollbars } from "react-custom-scrollbars-2";

export default function RecentJobsPosted() {
  return (
    <>
      <Stack
        backgroundColor="white"
        borderRadius="10px"
        border="2px solid silver"
        p={{ xs: 1, sm: 2 }}
      >
        <Typography
          color="inherit"
          variant="h4"
          fontWeight={800}
          p={{
            xs: "1rem 0rem",
            sm: "7px 0px",
            md: "5px 0px",
            lg: "2px 0px",
          }}
          fontSize={{ xs: "1.5rem", sm: "1.2rem", md: "1.8rem", lg: "2rem" }}
        >
          Recent Jobs Posted
        </Typography>
        <Scrollbars
          autoHide
          autoHideTimeout={0}
          autoHideDuration={0}
          autoHeight
          autoHeightMax={517}
        >
          <Grid container>
            {jobs.map((item) => {
              return (
                <Grid
                  item
                  xs={12}
                  p={0.5}
                  mt={1}
                  key={item.id}
                  sx={{
                    backgroundColor: "white",
                    borderRadius: "10px",
                    border: "2px solid silver",
                  }}
                >
                  <CardContent sx={{ cursor: "pointer" }}>
                    <Typography
                      sx={{ fontSize: 14, fontWeight: 800 }}
                      color="primary"
                      gutterBottom
                      cursor="pointer"
                    >
                      {item.post}
                    </Typography>

                    <Typography
                      variant="body2"
                      maxHeight="9rem"
                      overflow="hidden"
                    >
                      {item.description}
                    </Typography>
                    <Stack
                      p="10px 0px"
                      direction="row"
                      justifyContent="space-between"
                    >
                      <Stack direction="row">
                        <Box
                          component="img"
                          src={locationGray}
                          width="1rem"
                          height="1rem"
                        />
                        <Typography
                          p="0px 5px"
                          fontSize={{ xs: "10px", lg: "12px" }}
                          color="gray"
                        >
                          {item.city}
                        </Typography>
                      </Stack>
                      <Stack direction="row">
                        <WatchLaterOutlinedIcon
                          sx={{
                            color: "gray",
                            width: "1rem",
                            height: "1rem",
                          }}
                        />
                        <Typography
                          p="0px 5px"
                          fontSize={{ xs: "10px", lg: "12px" }}
                          color="gray"
                        >
                          {item.timings}
                        </Typography>
                      </Stack>
                    </Stack>
                  </CardContent>
                  <CardActions sx={{ cursor: "pointer" }}>
                    <Stack
                      direction="row"
                      width="100%"
                      justifyContent="space-between"
                    >
                      <Stack>
                        <Button
                          size="small"
                          variant="fiiled"
                          sx={{
                            backgroundColor: "black",
                            color: "white",
                            "&:hover": {
                              color: "white",
                              backgroundColor: "black",
                            },
                          }}
                        >
                          Apply
                        </Button>
                      </Stack>
                      <Stack>
                        <Typography m={1} fontSize="small" color="gray">
                          {item.postTime}
                        </Typography>
                      </Stack>
                    </Stack>
                  </CardActions>
                </Grid>
              );
            })}
          </Grid>
        </Scrollbars>
      </Stack>
    </>
  );
}
