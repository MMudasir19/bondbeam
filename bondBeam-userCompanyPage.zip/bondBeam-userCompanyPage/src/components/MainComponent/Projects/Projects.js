import * as React from "react";
import { Stack, Typography, Box } from "@mui/material";
import { useAPI } from "../../Hooks/useContext";
import MoreVertSharpIcon from "@mui/icons-material/MoreVertSharp";

export default function Projects() {
  const { data } = useAPI();
  const projects = data.company_projects;
  return (
    <>
      <Stack
        sx={{
          backgroundColor: "white",
          padding: 2,
          border: "2px solid silver",
          borderRadius: "10px",
        }}
      >
        <Typography
          color="inherit"
          variant="h4"
          fontWeight={800}
          mb={2}
          p={{ sm: "7px 0px", md: "5px 0px", lg: "2px 0px" }}
          fontSize={{ xs: "2rem", sm: "1.2rem", md: "1.8rem", lg: "2rem" }}
        >
          Projects
        </Typography>
        {projects.map((item) => {
          return (
            <Box
              key={item.id}
              width="100%"
              border="1px solid #9b9999"
              borderRadius={1}
              boxShadow="0px 2px #888888"
              sx={{
                margin: "5px 0px",
                cursor: "pointer",
              }}
            >
              <Stack>
                <Stack
                  direction="row"
                  justifyContent="space-between"
                  width="100%"
                >
                  <Stack direction="row">
                    <Box
                      component="img"
                      src={item.profile_pic}
                      p={1}
                      width="3.5rem"
                    />

                    <Stack>
                      <Typography variant="h6" color="inherit" fontWeight={800}>
                        {item.project_name}
                      </Typography>

                      <Typography variant="span" color="primary">
                        ID Associated with
                        <Typography variant="span" fontWeight={700} ml={0.5}>
                          {item.company}
                        </Typography>
                      </Typography>
                      <Typography variant="span" color="gray">
                        {item.start_date} - {item.end_date}
                      </Typography>
                    </Stack>
                  </Stack>
                  <Stack>
                    <Typography variant="h6" color="inherit" fontWeight={800}>
                      <MoreVertSharpIcon
                        fontSize="large"
                        sx={{
                          transform: {
                            xs: "rotateZ(180deg)",
                            sm: "rotateZ(90deg)",
                          },
                          color: "gray",
                          cursor: "pointer",
                        }}
                      />
                    </Typography>
                  </Stack>
                </Stack>
              </Stack>
              <Stack>
                <Stack direction="row" m="0rem 4rem" mt={4} flexWrap="wrap">
                  {item.images.map((item) => {
                    return (
                      <Box
                        boxShadow="1px 4px 6px #888888"
                        component="img"
                        src={item.pic}
                        key={item.id}
                        width="6rem"
                        m="0.5rem"
                        borderRadius={2}
                      />
                    );
                  })}
                </Stack>
              </Stack>
            </Box>
          );
        })}
      </Stack>
    </>
  );
}
