import React from "react";
import Button from "@mui/material/Button";
import { Typography } from "@mui/material";
import { useShowMore } from "../../Hooks/useShowMore";

export default function ChatDescription({ description }) {
  const { showMore, setShowMore } = useShowMore();
  return (
    <>
      <Typography
        fontSize={{
          xs: "small",
          "@media (max-width: 280px)": {
            fontSize: "10px",
          },
        }}
        variant="body2"
        color="gray"
        transition="all .3s ease"
      >
        {showMore ? description : `${description.substring(0, 200)}.....`}
        <Button
          onClick={() => setShowMore(!showMore)}
          variant="text"
          disableRipple
          sx={{
            fontSize: "x-small",
            textDecoration: "underline",
            "&:hover": {
              textDecoration: "underline",
            },
            "@media (max-width: 280px)": {
              fontSize: "8px",
            },
          }}
        >
          {showMore ? "Show less" : "Show more"}
        </Button>
      </Typography>
    </>
  );
}
