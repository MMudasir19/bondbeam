import { Stack, Typography, Grid, Box } from "@mui/material";
import * as React from "react";
import chats from "./ChatsData";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import CommentOutlinedIcon from "@mui/icons-material/CommentOutlined";
import ChatDescription from "./ChatDescription";
import FlagIcon from "@mui/icons-material/Flag";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import { useReport } from "../../Hooks/useReport";
import MoreVertSharpIcon from "@mui/icons-material/MoreVertSharp";
import ReportIcon from "@mui/icons-material/Report";
import Zoom from "react-medium-image-zoom";
import "react-medium-image-zoom/dist/styles.css";
import SendIcon from "@mui/icons-material/Send";
import ShareIcon from "@mui/icons-material/Share";
import TextField from "@mui/material/TextField";

export default function Chats() {
  const { anchorEl, handleClose, handleMenu } = useReport();

  return (
    <>
      <Grid
        container
        sx={{
          backgroundColor: "white",
          borderRadius: "10px",
          border: "2px solid silver",
          padding: 2,
        }}
      >
        <Grid
          item
          container
          xs={12}
          maxHeight={560}
          overflow="auto"
          sx={{
            "::-webkit-scrollbar": {
              display: "none",
            },
            msOverflowStyle: "none",
            scrollbarWidth: "none",
          }}
        >
          {chats.map((item) => {
            return (
              <Grid
                item
                xs={12}
                key={item.id}
                mt={2}
                borderBottom="1px solid #9b9999"
              >
                <Grid
                  sx={{ cursor: "pointer" }}
                  xs={12}
                  item
                  container
                  direction="row"
                  width="100%"
                  justifyContent="space-between"
                >
                  <Stack direction="row" p={{ xs: 0, sm: 1 }}>
                    <Stack
                      borderRadius="50%"
                      border="1px solid black"
                      p={{ xs: 1.3, lg: 2 }}
                      width={{ xs: "1rem", sm: "1.5rem" }}
                      height={{ xs: "1rem", sm: "1.5rem" }}
                    >
                      <Box
                        component="img"
                        src={item.logo}
                        width="100%"
                        height="100%"
                      />
                    </Stack>

                    <Stack m={{ xs: 0.5, lg: 1 }} mt={{ xs: 0.5, lg: 1 }}>
                      <Typography
                        variant="h6"
                        fontWeight={800}
                        color="black"
                        fontSize={{ xs: "small", lg: "large" }}
                      >
                        {item.title}
                      </Typography>
                      <Typography
                        variant="bosy2"
                        fontWeight={500}
                        color="gray"
                        fontSize={{ xs: "x-small", lg: "small" }}
                      >
                        {item.date}
                      </Typography>
                    </Stack>
                  </Stack>
                  <Stack direction="row" alignItems="center">
                    <Stack
                      size="large"
                      aria-label="account of current user"
                      aria-controls="menu-appbar"
                      aria-haspopup="true"
                      onClick={handleMenu}
                      color="inherit"
                    >
                      <MoreVertSharpIcon
                        fontSize="large"
                        sx={{
                          color: "gray",
                          cursor: "pointer",
                        }}
                      />
                    </Stack>
                    <Menu
                      sx={{ margin: "2rem 10rem 0rem 0rem" }}
                      id="menu-appbar"
                      anchorEl={anchorEl}
                      anchorOrigin={{
                        vertical: "top",
                        horizontal: "right",
                      }}
                      keepMounted
                      transformOrigin={{
                        vertical: "top",
                        horizontal: "right",
                      }}
                      open={Boolean(anchorEl)}
                      onClose={handleClose}
                    >
                      <MenuItem onClick={handleClose}>
                        <ReportIcon
                          fontSize="medium"
                          sx={{
                            color: "gray",
                          }}
                        />
                        Delete
                      </MenuItem>
                      <MenuItem onClick={handleClose}>
                        <FlagIcon
                          fontSize="medium"
                          sx={{
                            color: "gray",
                          }}
                        />
                        Report Post
                      </MenuItem>
                    </Menu>
                  </Stack>
                </Grid>
                <Grid item xs={11} p={1}>
                  <ChatDescription {...item} />
                </Grid>
                <Grid item xs={12}>
                  <Stack width="100%" sx={{ cursor: "pointer" }}>
                    <Zoom>
                      <img alt="noImg" src={item.chatImg} width="500" />
                    </Zoom>
                  </Stack>
                </Grid>
                <Grid item xs={12} mt={1}>
                  <Stack
                    sx={{ cursor: "pointer" }}
                    direction="row"
                    justifyContent="space-evenly"
                    width="100%"
                  >
                    <Stack
                      direction="row"
                      sx={{
                        color: "gray",
                        width: "100%",
                        display: "flex",
                        justifyContent: "center",
                        padding: "5px 10px",
                        borderRadius: "5px",
                        "&:hover": {
                          backgroundColor: "#E5E5E5",
                          color: "black",
                        },
                      }}
                    >
                      <ThumbUpIcon
                        sx={{
                          padding: "0px 5px",
                          width: { xs: "1rem", lg: "1.5rem" },
                          height: { xs: "1rem", lg: "1.5rem" },
                        }}
                      />
                      <Typography
                        variant="body2"
                        p="0px 5px"
                        fontSize={{
                          xs: "10px",
                          lg: "medium",
                        }}
                      >
                        {item.likes}
                      </Typography>
                    </Stack>
                    <Stack
                      direction="row"
                      sx={{
                        color: "gray",
                        width: "100%",
                        display: "flex",
                        justifyContent: "center",
                        padding: "5px 10px",
                        borderRadius: "5px",
                        "&:hover": {
                          backgroundColor: "#E5E5E5",
                          color: "black",
                        },
                      }}
                    >
                      <CommentOutlinedIcon
                        sx={{
                          padding: "0px 5px",
                          width: { xs: "1rem", lg: "1.5rem" },
                          height: { xs: "1rem", lg: "1.5rem" },
                        }}
                      />
                      <Typography
                        variant="body2"
                        p="0px 5px"
                        fontSize={{ xs: "10px", lg: "medium" }}
                      >
                        {item.comments}
                      </Typography>
                    </Stack>
                    <Stack
                      direction="row"
                      sx={{
                        color: "gray",
                        width: "100%",
                        display: "flex",
                        justifyContent: "center",
                        padding: "5px 10px",
                        borderRadius: "5px",
                        "&:hover": {
                          backgroundColor: "#E5E5E5",
                          color: "black",
                        },
                      }}
                    >
                      <ShareIcon
                        sx={{
                          padding: "0px 5px",
                          width: { xs: "1rem", lg: "1.5rem" },
                          height: { xs: "1rem", lg: "1.5rem" },
                        }}
                      />
                      <Typography
                        variant="body2"
                        p="0px 5px"
                        fontSize={{ xs: "10px", lg: "medium" }}
                      >
                        {item.shares}
                      </Typography>
                    </Stack>
                  </Stack>
                </Grid>
                <Grid item xs={12} p={1}>
                  <Stack
                    direction="row"
                    justifyContent="space-between"
                    width="100%"
                  >
                    <Stack direction="row" width="100%" display="flex">
                      <Stack
                        width="3rem"
                        height="2.5rem"
                        sx={{ cursor: "pointer" }}
                      >
                        <Box
                          component="img"
                          src={item.userImg}
                          width="100%"
                          height="100%"
                          borderRadius="50%"
                        />
                      </Stack>
                      <Stack width="100%" p={"0px 10px"}>
                        <TextField
                          sx={{
                            backgroundColor: "#F5F5F5",
                            width: "100%",
                            "& .MuiInputBase-root": {
                              height: 40,
                              borderColor: "gray",
                              " &.Mui-focused fieldset": {
                                borderColor: "black",
                              },
                            },
                          }}
                          id="standard-basic"
                          variant="outlined"
                          placeholder="Write your comment"
                        />
                      </Stack>
                      <SendIcon
                        fontSize="medium"
                        sx={{
                          "&:hover": {
                            color: "rgb(46 91 223)",
                          },
                          color: "gray",
                          cursor: "pointer",
                          marginTop: 0.7,
                        }}
                      />
                    </Stack>
                  </Stack>
                </Grid>
              </Grid>
            );
          })}
        </Grid>
      </Grid>
    </>
  );
}
