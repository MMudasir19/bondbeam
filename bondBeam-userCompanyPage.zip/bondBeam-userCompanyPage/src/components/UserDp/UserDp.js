import * as React from "react";
import { Box } from "@mui/system";
import Button from "@mui/material/Button";
import MoreVertSharpIcon from "@mui/icons-material/MoreVertSharp";
import userLocation from "../../images/userlocation.png";
import Divider from "@mui/material/Divider";
import WatchLaterOutlinedIcon from "@mui/icons-material/WatchLaterOutlined";
import { makeStyles } from "@mui/styles";
import { Grid, Stack, Typography } from "@mui/material";
import PeopleOutlineIcon from "@mui/icons-material/PeopleOutline";
import { useShowMore } from "../Hooks/useShowMore";
import { useAPI } from "../Hooks/useContext";

const userDpStyles = makeStyles({
  root: {
    backgroundSize: "cover",
    backgroundPosition: "center center",
    backgroundRepeat: "no-repeat",
    height: "25rem",
  },
});

export default function UserDp() {
  const styles = userDpStyles();
  const { data } = useAPI();
  const detail = data.company;
  const { showMore, setShowMore } = useShowMore();
  return (
    <Grid container>
      <Grid
        item
        container
        xs={12}
        className={styles.root}
        sx={{ backgroundImage: `url(${detail.cover_pic})` }}
        p={{
          xs: "5%",
          sm: "1.5%",
          "@media (max-width: 280px)": {
            padding: "8%",
          },
        }}
        alignItems={{ sm: "flex-end" }}
      >
        <Grid item xs={12}>
          <Stack direction="row" columnGap={1} alignItems={{ sm: "center" }}>
            <Stack>
              <Box
                component={"img"}
                sx={{ cursor: "pointer" }}
                alt="no img"
                src={detail.profile_pic}
                borderRadius={{ xs: "10%", sm: "50%" }}
                width={{
                  xs: 80,
                  sm: 120,
                  lg: 140,
                  "@media (max-width: 280px)": {
                    width: 60,
                  },
                }}
              />
            </Stack>
            <Stack
              direction={{ sm: "row" }}
              justifyContent="space-between"
              width="100%"
            >
              <Stack>
                <Typography
                  color="white"
                  variant="h6"
                  fontSize="medium"
                  sx={{ cursor: "pointer" }}
                >
                  {detail.company_name}
                </Typography>

                <Typography
                  fontSize="small"
                  variant="p"
                  color="#b3b2af"
                  fontWeight={600}
                >
                  Construction Company
                </Typography>
                <Typography
                  fontSize={{
                    xs: "small",
                    "@media (max-width: 280px)": {
                      fontSize: "10px",
                    },
                  }}
                  variant="p"
                  color="white"
                  maxWidth={{ md: "85%", lg: "55%" }}
                  overflow="auto"
                  maxHeight="9rem"
                  transition="all .3s ease"
                >
                  {showMore
                    ? detail.company_description
                    : `${detail.company_description.substring(0, 200)}.....`}
                  <Button
                    onClick={() => setShowMore(!showMore)}
                    variant="text"
                    disableRipple
                    sx={{
                      fontSize: "x-small",
                      textDecoration: "underline",
                      "&:hover": {
                        textDecoration: "underline",
                      },
                      "@media (max-width: 280px)": {
                        fontSize: "8px",
                      },
                    }}
                  >
                    {showMore ? "Show less" : "Show more"}
                  </Button>
                </Typography>
                <Typography
                  fontSize={{
                    xs: "small",
                    "@media (max-width: 280px)": {
                      fontSize: "10px",
                    },
                  }}
                >
                  {detail.web_link}
                </Typography>
                <Stack direction={{ sm: "row" }} mt="1rem">
                  <Stack
                    sx={{ cursor: "pointer" }}
                    direction="row"
                    m={{
                      xs: 1,
                      sm: 0,
                      "@media (max-width: 280px)": {
                        margin: "2px",
                      },
                    }}
                  >
                    <Box
                      component={"img"}
                      src={userLocation}
                      alt="no img"
                      width={{ xs: "0.7rem", md: "1rem" }}
                      height={{ xs: "0.7rem", md: "1rem" }}
                    />
                    <Typography
                      fontSize={{
                        xs: "10px",
                        md: "small",
                        "@media (max-width: 280px)": {
                          fontSize: "10px",
                        },
                      }}
                      color="white"
                      p={{ xs: "0rem 0.3rem", lg: "0rem 1rem" }}
                    >
                      {detail.company_address}
                    </Typography>
                    <Divider
                      orientation="vertical"
                      flexItem
                      sx={{
                        display: { xs: "none", sm: "block" },
                        borderRightWidth: 2,
                        bgcolor: "white",
                        margin: { xs: "0rem 0.3rem", lg: "0rem 1rem" },
                      }}
                    />
                  </Stack>

                  <Stack
                    sx={{ cursor: "pointer" }}
                    direction="row"
                    m={{
                      xs: 1,
                      sm: 0,
                      "@media (max-width: 280px)": {
                        margin: "2px",
                      },
                    }}
                  >
                    <WatchLaterOutlinedIcon
                      sx={{
                        color: "white",
                        width: { xs: "1rem", md: "1.5rem" },
                        marginTop: { xs: "-3px", lg: "0px" },
                      }}
                    />
                    <Typography
                      fontSize={{
                        xs: "10px",
                        md: "small",
                      }}
                      color="white"
                      p={{ xs: "0rem 0.3rem", lg: "0rem 1rem" }}
                    >
                      {detail.working_shift}
                    </Typography>
                    <Divider
                      orientation="vertical"
                      flexItem
                      sx={{
                        display: { xs: "none", sm: "block" },
                        borderRightWidth: 2,
                        bgcolor: "white",
                        margin: { xs: "0rem 0.3rem", lg: "0rem 1rem" },
                      }}
                    />
                  </Stack>
                  <Stack
                    sx={{ cursor: "pointer" }}
                    direction="row"
                    m={{
                      xs: 1,
                      sm: 0,
                    }}
                  >
                    <PeopleOutlineIcon
                      sx={{
                        color: "white",
                        width: { xs: "1rem", md: "1.5rem" },
                        marginTop: { xs: "-3px", lg: "0px" },
                      }}
                    />
                    <Typography
                      fontSize={{
                        xs: "10px",
                        md: "small",
                      }}
                      p={{ xs: "0rem 0.3rem", lg: "0rem 1rem" }}
                      color="white"
                    >
                      {detail.company_employees}
                    </Typography>
                    <Typography
                      fontSize={{
                        xs: "10px",
                        md: "small",
                      }}
                      cursor="pointer"
                      color="#1976d2"
                      sx={{ textDecoration: "underline" }}
                    >
                      View all
                    </Typography>
                  </Stack>
                </Stack>
              </Stack>
              <Stack direction="row" m={{ xs: 1, sm: 0 }}>
                <Stack>
                  <Button
                    size="small"
                    variant="outlined"
                    sx={{
                      borderColor: "white",
                      color: "white",
                      "&:hover": {
                        color: "white",
                        borderColor: "white",
                      },
                    }}
                  >
                    Following
                  </Button>
                </Stack>

                <MoreVertSharpIcon
                  fontSize="large"
                  sx={{
                    transform: {
                      xs: "rotateZ(90deg)",
                      sm: "rotateZ(180deg)",
                    },
                    color: "white",
                    cursor: "pointer",
                  }}
                />
              </Stack>
            </Stack>
          </Stack>
        </Grid>
      </Grid>
    </Grid>
  );
}
